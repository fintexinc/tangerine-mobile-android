package data.mock

const val BASIC_INFO_MOCK = "[\n" +
        "    {\n" +
        "        \"investorName\": \"Alex Tremblay\",\n" +
        "        \"investorId\": \"INV-0001\"\n" +
        "    },\n" +
        "    {\n" +
        "        \"investorName\": \"Sophie Dubois\",\n" +
        "        \"investorId\": \"INV-0002\"\n" +
        "    }\n" +
        "]\n" +
        "\n"