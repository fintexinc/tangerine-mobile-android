package data.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import data.repository.LocalAccountRepository
import domain.repository.AccountRepository

@Module
@InstallIn(SingletonComponent::class)
class NetworkModule {

    // TODO: Replace with remote implementation when available
    @Provides
    fun provideAccountRepository(): AccountRepository {
        return LocalAccountRepository()
    }
}